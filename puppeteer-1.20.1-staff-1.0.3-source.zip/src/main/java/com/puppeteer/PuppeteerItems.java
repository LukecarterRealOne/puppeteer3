package com.puppeteer;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

/** Registers Puppeteer's Staff and makes it easy to find in Creative mode. */
public final class PuppeteerItems {
    public static final Item PUPPETEER_STAFF = register(
            "puppeteer_staff",
            new PuppeteerWand(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC))
    );

    private PuppeteerItems() {}

    private static <T extends Item> T register(String name, T item) {
        return Registry.register(
                BuiltInRegistries.ITEM,
                new ResourceLocation(PuppeteerMod.MOD_ID, name),
                item
        );
    }

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(entries -> entries.accept(PUPPETEER_STAFF));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT)
                .register(entries -> entries.accept(PUPPETEER_STAFF));
    }
}
