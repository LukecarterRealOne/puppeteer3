package com.puppeteer;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public final class PuppeteerWand extends Item {
    public PuppeteerWand(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player user, InteractionHand hand) {
        if (!level.isClientSide() && user instanceof ServerPlayer serverPlayer) {
            if (user.isShiftKeyDown()) {
                PuppeteerControl.releaseAll(serverPlayer);
            } else {
                PuppeteerControl.cycleOrder(serverPlayer);
            }
        }
        return InteractionResultHolder.sidedSuccess(user.getItemInHand(hand), level.isClientSide());
    }
}
