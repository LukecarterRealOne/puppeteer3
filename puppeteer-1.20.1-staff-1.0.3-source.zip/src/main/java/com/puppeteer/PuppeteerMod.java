package com.puppeteer;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;

public final class PuppeteerMod implements ModInitializer {
    public static final String MOD_ID = "puppeteer";

    @Override
    public void onInitialize() {
        PuppeteerItems.initialize();
        System.out.println("[Puppeteer] Registered item: puppeteer:puppeteer_staff");

        // Defer delivery until the server has completed the join event. This makes
        // the initial staff grant reliable for new and returning single-player users.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                server.execute(() -> giveStaffIfMissing(handler.player)));

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("puppeteer")
                        .then(Commands.literal("staff").executes(context -> {
                            giveStaff(context.getSource().getPlayerOrException());
                            return 1;
                        }))
                        // Keep the earlier command as a compatibility alias.
                        .then(Commands.literal("wand").executes(context -> {
                            giveStaff(context.getSource().getPlayerOrException());
                            return 1;
                        }))
                        .then(Commands.literal("help").executes(context -> {
                            ServerPlayer player = context.getSource().getPlayerOrException();
                            PuppeteerControl.message(player,
                                    "Staff item ID: puppeteer:puppeteer_staff. Use /puppeteer staff to get one. " +
                                    "Right-click an existing mob to recruit/release it; right-click air to cycle orders; " +
                                    "sneak + right-click air to release all.");
                            return 1;
                        }))));

        UseEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            if (!player.getItemInHand(hand).is(PuppeteerItems.PUPPETEER_STAFF)) {
                return InteractionResult.PASS;
            }

            if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
                if (entity instanceof Mob mob) {
                    PuppeteerControl.togglePuppet(serverPlayer, mob);
                } else {
                    PuppeteerControl.message(serverPlayer, "That entity can't be puppeteered.");
                }
            }
            return InteractionResult.SUCCESS;
        });

        ServerTickEvents.END_SERVER_TICK.register(PuppeteerControl::tick);
    }

    private static boolean hasStaff(ServerPlayer player) {
        return player.getInventory().items.stream()
                .anyMatch(stack -> stack.is(PuppeteerItems.PUPPETEER_STAFF))
                || player.getInventory().offhand.stream()
                .anyMatch(stack -> stack.is(PuppeteerItems.PUPPETEER_STAFF));
    }

    private static void giveStaffIfMissing(ServerPlayer player) {
        if (!hasStaff(player)) {
            giveStaff(player);
        } else {
            PuppeteerControl.message(player,
                    "Puppeteer's Staff is registered. If you need another, run /puppeteer staff.");
        }
    }

    private static void giveStaff(ServerPlayer player) {
        ItemStack staff = new ItemStack(PuppeteerItems.PUPPETEER_STAFF);
        if (!player.getInventory().add(staff)) {
            player.drop(staff, false);
        }
        PuppeteerControl.message(player,
                "You received Puppeteer's Staff (puppeteer:puppeteer_staff). Right-click a mob to recruit it; " +
                "right-click air to change orders. Use /puppeteer help for controls.");
    }
}
