# Puppeteer 1.0.3 — Minecraft Java 1.20.1 (Fabric)

This is a source project for a Fabric mod for **Minecraft Java 1.20.1**, built with **Java 17**.

## Get the staff

- In a single-player world, the mod grants Puppeteer's Staff when you join if you do not already have one.
- If you need another, run `/puppeteer staff`.
- Direct item test: `/give @s puppeteer:puppeteer_staff`.
- Search Creative inventory for **Puppeteer's Staff**. It is inserted into Tools & Utilities and Combat.
- Craft it with two sticks and an amethyst shard.

If `/give @s puppeteer:puppeteer_staff` says the item does not exist, the game is not running the 1.0.3 JAR from this project. Remove older Puppeteer JARs and keep only `puppeteer-1.0.3.jar`.

## Controls

- Right-click an existing Mob with the staff to recruit it. Right-click a recruited mob to release it.
- Right-click air to cycle through Follow Me, Stay, Roam Nearby, and Attack Nearby Hostiles.
- Sneak + right-click air to release all recruited mobs.
- `/puppeteer help` prints controls.

The mod controls existing mobs; it does **not** automatically spawn new mobs. Some modded mobs with custom AI may not obey all orders.

## Important: where it must be installed

This mod registers a real Minecraft item and changes mob behavior on the server. It works in single-player when installed in the active Fabric profile. On a multiplayer server, the server must also run the same mod; a client-only install cannot create an item the server does not know about.

## Build with GitHub Actions

Upload this ZIP and `build.yml` to the root of your GitHub repository. The workflow in `build.yml` intentionally extracts and builds this exact source ZIP in a clean temporary directory, rather than accidentally compiling older Gradle files at the repository root. It uploads a JAR artifact named `puppeteer-minecraft-1.20.1`.

This project has not been compiled or tested in Minecraft from this environment. The GitHub Actions run is the build verification step.
